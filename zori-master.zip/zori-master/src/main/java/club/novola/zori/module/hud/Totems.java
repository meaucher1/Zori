package club.novola.zori.module.hud;

import club.novola.zori.module.Module;

public class Totems extends Module {
    public Totems() {
        super("Totems", Category.HUD);
        INSTANCE = this;
    }

    public static Totems INSTANCE;
}
