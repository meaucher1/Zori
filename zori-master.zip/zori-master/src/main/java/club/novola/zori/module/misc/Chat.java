package club.novola.zori.module.misc;

import club.novola.zori.module.Module;

public class Chat extends Module {
    public Chat() {
        super("Chat", Category.MISC);
    }
}
