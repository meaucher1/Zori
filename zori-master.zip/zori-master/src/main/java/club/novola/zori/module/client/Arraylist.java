package club.novola.zori.module.client;

import club.novola.zori.module.Module;

public class Arraylist extends Module {

    public Arraylist() {
        super("Arraylist", Category.CLIENT);
        INSTANCE = this;
    }

    public static Arraylist INSTANCE;

}
