# Zori
A 1.12.2 utility mod designed towards anarchy crystalpvp
## Devs
Novola, BrownZombie, chell/FINZ0, chardnol, divisiion
## How to Use
Download from Novola/zori-releases or build the jar yourself
